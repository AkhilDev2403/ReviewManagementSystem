package com.commercetools.reviewmanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReviewManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReviewManagementSystemApplication.class, args);
	}

}
