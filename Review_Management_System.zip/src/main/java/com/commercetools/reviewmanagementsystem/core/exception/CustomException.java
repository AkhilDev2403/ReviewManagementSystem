package com.commercetools.reviewmanagementsystem.core.exception;

public class CustomException extends RuntimeException{
    public CustomException(String message) {
        super(message);
    }
}
